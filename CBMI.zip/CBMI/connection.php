<?php
    $servername = "localhost";
    $username = "root";
    $pass = "";
    $dbname = "newbmi";
    
    // Create connection
    $conn = mysqli_connect($servername,$username, $pass, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>